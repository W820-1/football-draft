Football Draft FINAL

Enthält 20 Rolls, Ronaldo-Banner zwischen Roll-Bereich und Bestenliste sowie die vorherigen Funktionen.
Die Datei kann als statische Website veröffentlicht werden. Für Live-Spielerdaten benötigt der Browser Internetzugriff.
